Exported from Annotrix on 2026-11-24 19:04 UTC
Project: Study Assisted
Format: coco
Images: 20
