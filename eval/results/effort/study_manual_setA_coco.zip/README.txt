Exported from Annotrix on 2026-11-24 16:53 UTC
Project: Study manual
Format: coco
Images: 20
